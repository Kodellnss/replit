contact_informations = {
  "operator_company": "Pacific Drilling Inc.",
  "contact_person": "Smith John",
  "phone": "+1-555-123-4567",
  "email": "john.smith@oceanicdrilling.com",
}

for test in contact_informations.items():
  print(test)
