from string_tils import zfill_machine_id
print(zfill_machine_id("DM-4"))