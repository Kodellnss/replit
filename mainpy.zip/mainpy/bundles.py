import json

import json 

with open("fichier.json", "r") as fichier :
  donnees = json.load(fichier)
print(donnees)




