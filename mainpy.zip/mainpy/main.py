import json
from drill_utils import (
  fonction_date,
  fonction_km,
  ajout_info,
  machine_format,
)

file_to_read = "drilling_machine4.json"
file_to_write = f"updated_{file_to_read}"

with open(file_to_read, "r") as f :
  data = json.load(f)

if "depth_capacity_miles" in data["specifications"].keys() :
  data = fonction_km(data)
if "machine_id" in data.keys() or "machine_ID" in data.keys() :
  data = machine_format(data)
if "last_maintenance_date" in data.keys() :
  data = fonction_date(data)
if "contact_information" not in data.keys() : 
  data = ajout_info(data)


print(data)

with open(file_to_write, "w") as f:
  json.dump(data, f)